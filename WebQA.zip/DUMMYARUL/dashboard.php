<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
include "config/koneksi.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard QA</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
    <div class="card">

        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
            <h2>Dashboard QA</h2>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>

        <a href="tambah.php">+ Tambah Task</a>

        <table>
            <tr>
                <th>Title</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>

            <?php
            $data = mysqli_query($conn, "SELECT * FROM tasks");

            if (mysqli_num_rows($data) == 0) {
                echo "<tr><td colspan='3'>Belum ada task</td></tr>";
            }

            while ($d = mysqli_fetch_assoc($data)) {
            ?>
            <tr>
                <td><?= $d['title']; ?></td>
                <td>
                    <span class="status <?= strtolower(str_replace(' ', '', $d['status'])) ?>">
                        <?= $d['status']; ?>
                    </span>
                </td>
              <td>
    <a href="edit.php?id=<?= $d['id']; ?>">Edit</a> |
    <a href="hapus.php?id=<?= $d['id']; ?>" onclick="return confirm('Yakin hapus task ini?')">
        Hapus
    </a>
</td>

                
            </tr>
            <?php } ?>

        </table>

    </div>
</div>

</body>
</html>
