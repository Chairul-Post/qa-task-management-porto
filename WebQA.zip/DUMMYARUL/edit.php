<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include "config/koneksi.php";

$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM tasks WHERE id='$id'");
$d = mysqli_fetch_assoc($data);

if (!$d) {
    echo "Data tidak ditemukan";
    exit;
}

if (isset($_POST['update'])) {
    mysqli_query($conn, "UPDATE tasks SET
        title='$_POST[title]',
        description='$_POST[desc]',
        status='$_POST[status]'
        WHERE id='$id'
    ");
    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Task</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
    <div class="card">
        <h2>Edit Task QA</h2>

        <form method="post">
            <input type="text" name="title" value="<?= $d['title']; ?>" required>

            <textarea name="desc" required><?= $d['description']; ?></textarea>

            <select name="status" required>
                <option <?= ($d['status']=='Open')?'selected':''; ?>>Open</option>
                <option <?= ($d['status']=='In Progress')?'selected':''; ?>>In Progress</option>
                <option <?= ($d['status']=='Done')?'selected':''; ?>>Done</option>
            </select>

            <button type="submit" name="update">Update Task</button>
            <br><br>
            <a href="dashboard.php">← Kembali ke Dashboard</a>
        </form>
    </div>
</div>

</body>
</html>
