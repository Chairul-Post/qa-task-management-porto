<?php
include "config/koneksi.php";

if (isset($_POST['simpan'])) {
    mysqli_query($conn, "INSERT INTO tasks VALUES(
        '',
        '$_POST[title]',
        '$_POST[desc]',
        '$_POST[status]'
    )");
    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Task QA</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
    <div class="card">
        <h2>Tambah Task QA</h2>

        <form method="post">
            <input type="text" name="title" placeholder="Judul Task" required>

            <textarea name="desc" placeholder="Deskripsi Task" required></textarea>

            <select name="status" required>
                <option value="">-- Pilih Status --</option>
                <option>Open</option>
                <option>In Progress</option>
                <option>Done</option>
            </select>

            <button type="submit" name="simpan">Simpan Task</button>
            <br><br>
            <a href="dashboard.php">← Kembali ke Dashboard</a>
        </form>
    </div>
</div>

</body>
</h
