<?php
$conn = mysqli_connect("localhost", "root", "", "qa_porto");

if (!$conn) {
    die("Koneksi gagal");
}
?>
